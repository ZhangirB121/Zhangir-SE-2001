public interface Interface1 {
    public void method1();
}
