public interface Interface2 extends Interface1{
    public void method2();
}
